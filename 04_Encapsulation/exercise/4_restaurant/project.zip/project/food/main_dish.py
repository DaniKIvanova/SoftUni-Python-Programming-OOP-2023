from project.food.food import Food


class MainDish(Food):
    pass

